import { Component } from "react";
import {Route, NavLink, BrowserRouter, Routes} from "react-router-dom"
import { ProductsPage} from "./pages/productos.jsx"


import "./App.css"


class NavTo extends Component {

    constructor(props) {
        super(props);

        this.props = props
    } 


    props = {
        children:[],
        img:"",
        to:"",
    
    }

    render() {

        return(
            <NavLink to={this.props.to} key={`nav-control-div-` + this.props.to} className={(e) => {
                if (e.isActive) {
                    return "nav-active"
                }
            }}>
                <div className="navlink-base">
                    <div className="_icon" style={{
                        backgroundImage:`url('${this.props.img}')`
                    }}>

                    </div>
                    <div className="_caption">
                        {this.props.children}

                    </div>

                </div>

            </NavLink>      
        )

    }
}


class App extends Component {


    render() {

        return(

            <div className="marco">
                <div className="container">
                    <BrowserRouter>
                        <div className="nav-control">
                            <NavTo to="/" img="/src/imgs/nav/dashboard.svg">Panel principal</NavTo>
                            <NavTo to="/productos" img="/src/imgs/nav/products.svg">Productos</NavTo>
                            <NavTo to="/clientes" img="/src/imgs/nav/clients.svg">Clientes</NavTo>
                            <NavTo to="/facturas" img="/src/imgs/nav/cheks.svg">Facturas</NavTo>
                            <NavTo to="/reportes" img="/src/imgs/nav/report.svg">Reportes</NavTo>
                            <NavTo to="/conf" img="/src/imgs/nav/conf.svg">Configuraciones</NavTo>
                        </div>
                        <div className="body-content">
                            <Routes>
                                <Route path="/" element={[
                                    <div>
                                        Hola mundo
                                    </div>
                                ]}>
                                
                                </Route>
                                <Route index path="/productos" element={ <ProductsPage /> }></Route>
                            </Routes>
                        </div>
                    </BrowserRouter>

                </div>
            </div>
        )
    }
}

export default App;
