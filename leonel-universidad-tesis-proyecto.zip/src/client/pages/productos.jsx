import { Component } from "react";
import { Table } from "antd";

const columns = [
    { title: 'Codigo', dataIndex: 'id', key: 'id' },
    { title: 'Nombre Producto', dataIndex: 'name', key: 'name' },
    { title: 'Stock', dataIndex: 'stock', key: 'stock' },
];

const data = [
    { key: 1, name: 'Pan frances', stock: 25, id: 1 },
    { key: 2, name: 'Pan Canilla', stock: 30, id: 2 },
];

class ProductsPage extends Component {


    state = {
        productos:[],
        rowIndex: -1
    }

    componentDidMount() {

    }

    render() {


        return(
            <div className="container">


                <div className="top-control">
                    <form >
                        <h2 className="title-page">
                            Productos
                        </h2>
                        <input type="number" className="_input" name="id" placeholder="id del producto"/>
                        <input type="number" className="_input" name="stock" placeholder="Cantidad/Stock disponible" />
                        <input type="text" className="_input" name="name" placeholder="Nombre del producto" />
                        <br />
                        <br />
                        <hr />
                        <input type="submit" className="_submit" value={"Agregar"} />
                    </form>
                </div>


                <div className="table-container">

                    <Table dataSource={data} columns={columns} rowClassName={(e) => {
                        return "_row-table-antd " + e.key === this.state.rowIndex ?"active":""
                    }} onRow={(e) => {
                        

                        return {
                            onClick:(row) => {
                                this.setState({rowIndex: e.key});

                                console.log(e)
                            }
                            
                        }
                    }} ></Table>
                </div>

                <br />



            </div>
        )
    }
}




export {
    ProductsPage
}