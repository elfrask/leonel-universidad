import mongoose from "mongoose";
import { configDotenv } from "dotenv";

configDotenv();


mongoose.connect(process.env.MONGO)



let Productos = new mongoose.Schema({
    id: Number,
    
})