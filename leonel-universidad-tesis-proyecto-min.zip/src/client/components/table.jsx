import { Component } from "react";


class Table extends Component {

    constructor(props) {
        super(props);

        this.props = props
    };

    props = {

    }

    state = {
        
    }
    
    render() {

    }
}